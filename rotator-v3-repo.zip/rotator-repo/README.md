# ⬡ ROTATOR — Binance Rotation Screener

A crypto rotation screener tracking the **top 50 Binance-listed coins** by market cap.

## Features
- **Free tier:** Top 30 coins, full leaderboard, portfolio signal, BTC trend
- **Pro tier:** All 50 coins — unlocked free via referrals (3 friends = Pro)
- Live data via CoinGecko API with CORS proxy fallbacks
- 7D / 14D / 30D performance scoring
- Rotation opportunity suggestions
- BTC 200-day MA trend indicator

## Referral System
Pro is unlocked when 3 friends visit your unique referral link AND add at least one coin to their holdings. No payment needed.

## Deploy
This is a single-file static site. Deploy to Netlify by pointing to this repo — `netlify.toml` is already configured.

## Local Dev
Just open `public/index.html` in a browser. No build step required.
